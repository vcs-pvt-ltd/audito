
# Audito Platform Guide: Getting Started, Audits and Roles

## What is Audito?

Audito is an audit management platform for organizations that need a clearer way to plan audits, organize business entities, assign auditors, collect evidence, manage corrective actions, and review performance.

It brings the complete audit lifecycle into one workspace:

1. Set up the organization structure.
2. Add the people who will perform or oversee audits.
3. Create reusable audit checklists.
4. Assign audits to the right people and entities.
5. Record answers, findings and evidence during execution.
6. Raise and track Corrective Action Plans (CAPs).
7. Review reports, trends and completed audit results.

Audito can support internal audit programs as well as external, supplier, partner, and cross-company audit workflows where these are enabled for the workspace.

## Who can use Audito?

Audito is designed for organizations that manage compliance, quality, safety, operational, supplier, or internal audit work. Common workspace structures include:

- **Companies** that organize audits across clusters, factories, units, departments, and sections.
- **Customers and buying organizations** that work with buying offices and suppliers.
- **Audit firms** that receive client audit assignments and allocate them to their branches, departments, and auditors.

The available organization levels, limits, and advanced features are based on the workspace configuration and subscription. The latest options are always shown during registration and in the Audito pricing area.

## Registering and creating a workspace

To create a new Audito workspace, choose the organization account type that best reflects how your work is structured. Then provide the organization contact information, verify the organization email address, and set up the administrator account.

New registrations must agree to the current Privacy Policy. Audito records the policy version accepted at registration so organizations have a clear record of the agreement.

Some organizations need a tailored setup. In that case, select **Custom Solution**, choose the account type and required capacity, and submit the request for review. A custom request is reviewed before a tailored price and payment path are provided.

## Guided onboarding for new administrators

After sign-in, organization administrators can follow Audito's guided onboarding flow. It is designed to build the workspace in a practical order:

1. **Create the organization structure** — add the real locations, business units, departments, suppliers, or branches that need to be audited.
2. **Map the hierarchy** — connect entities to their parent entities so results roll up through the correct structure.
3. **Invite auditors** — add the people who carry out inspections and audit work.
4. **Assign entity heads** — for applicable organization types, assign the people who need read-only visibility of a specific unit.
5. **Create checklist types and checklists** — prepare the questions that will be used during audits.
6. **Launch an audit** — select a checklist, target entities, auditors, and dates.

The onboarding guide can be completed step by step or resumed later from the workspace. Administrators can also use the Help & Guidance page for role-specific instructions.

## Organization structure and hierarchy

Audito lets each workspace reflect its real operational structure. A company may organize audit scope through a chain such as **Company → Cluster → Factory → Unit → Department → Section**. A customer workspace may use **Customer → Buying Office → Supplier**. An audit firm can use its own company, branch, and department structure.

Create higher-level entities first, then add the lower-level entities under the correct parent. This makes it easier to assign auditors, filter reports, and understand where audit results belong.

Entity names can be reused when the same named unit is relevant in more than one place. The organization hierarchy keeps each placement in the correct parent context. Entity heads have read-only visibility for their assigned entity and its relevant child scope.

## Users and roles

### Organization administrator

The administrator configures the organization structure, users, checklists, audit assignments, settings, and subscription information. Administrators can monitor audit activity, corrective actions, and organization performance.

### Auditor

Auditors receive assigned audits, open them from **My Audits**, complete checklist answers, record findings, attach permitted evidence, submit reports, and carry out follow-up corrective action work in **My CAPs**.

### Entity head

An entity head has read-only oversight of audits and corrective actions within the assigned entity scope. Entity heads can review audit findings, evidence, trends, and CAP progress, but they do not change audit answers or approve results.

### Audito platform administrator

The Audito platform administration area manages platform-wide items such as plans, campaigns, payments, privacy policy versions, organization registrations, and published AI knowledge content. These controls affect the platform and should be reviewed carefully before changes are published.

## Creating checklists

Checklists are reusable questionnaires used by auditors during an audit. An administrator can:

- Create checklist types to group related checklists, such as Safety, Quality, Compliance, or Operations.
- Add questions manually and configure the answer type, answer options, scoring, and the entities where each question applies.
- Import checklist questions from a supported Excel template.
- Where enabled, use approved reference material to generate suggested checklist questions with AI, then review the questions before importing them into the checklist.

Audito supports question formats such as free-text answers, single-choice answers, multiple-choice answers, and dropdown answers. For scored choice questions, the option points should be reviewed before the checklist is used in an audit.

Once a checklist has been assigned to an audit, it should be treated as the audit record for that assignment. This protects the consistency of the audit and its completed report.

## Assigning and completing audits

An audit assignment connects a checklist to the people and organization entities that need to be audited. During assignment, an administrator selects the checklist, target entities, auditors, schedule, and any applicable audit details. An email notification can be sent to assigned auditors.

Auditors complete the work from **My Audits**:

1. Open the planned audit.
2. Read each checklist question for the relevant entity.
3. Enter the answer and any required notes or findings.
4. Attach permitted evidence when it supports the finding.
5. Review the audit preview and complete the report.

Audit statuses help everyone follow the work from planned to in progress and completed. Completed audits can be opened in view mode to review the report and evidence.

## Evidence and reports

Evidence gives context to audit answers and findings. Depending on the workspace features and evidence rules, auditors can attach supported files such as images, documents, audio, or video. Evidence is visible to the people who have permission to review the relevant audit or CAP.

Audito reports bring together audit answers, findings, corrective actions, and organization details. When an organization logo has been added in settings, it can appear alongside Audito branding in audit and CAP report headers.

## Corrective Action Plans (CAPs)

When an audit finding needs follow-up, a Corrective Action Plan can be raised. CAPs help teams record the issue, assign actions, set due dates, collect follow-up information, and monitor progress until resolution.

A typical CAP workflow is:

1. Identify the finding from an audit response.
2. Create the corrective action and set a due date.
3. Assign the follow-up work to the responsible auditor or team.
4. Record actions, evidence, and outcomes.
5. Complete the CAP report when the issue has been addressed.

Administrators and relevant entity heads can monitor CAP progress. Notifications keep the appropriate users informed when audit and CAP work requires attention.

## Audit comparison and performance insight

Audito can help organizations compare completed audits that use the same checklist. This is useful for seeing how a repeated audit has changed over time across an organization or selected entity scope.

Use the dashboard and audit comparison tools to review completed performance, focus on a specific organization entity, and identify recurring improvement areas. Results are intended to support operational decisions; teams should always review the underlying audit evidence and context as well.

## Learning for auditors

The Learning area supports auditor development through:

- **Trainings** — assigned learning material, including supported video learning workflows.
- **Field Visits** — planned on-site learning or observation visits, including location details where used.
- **Evaluation Papers** — assessments that help organizations review auditor knowledge and competency.

Assigned learning activities appear under **My Learning** for the auditor. Administrators can send assignment emails and in-app notifications when they assign learning work.

## Notifications and email

Audito uses notifications and email to help people stay on top of work that needs attention. Examples include audit assignments, learning assignments, corrective action activity, and important subscription reminders.

Opening a notification can take the user to the related area of the system, where available. Notification availability and delivery depend on the recipient's role, permissions, and workspace configuration.

## Settings, billing and support

Organization administrators can manage workspace-wide settings, including organization information, contact details, logo, timezone, notices, notification preferences, and billing.

The Billing area provides the current plan, renewal information, plan limits, and available billing actions. Plans, pricing, discounts, included limits, and feature availability can change over time, so visitors should refer to the current pricing page or contact Audito for the most accurate commercial information.

For product questions, custom requirements, or sales assistance, use the **Contact Us** area on the Audito website or email [hi@audito.cloud](mailto:hi@audito.cloud).

## Privacy and safe use of Audito AI

Audito's public AI assistant is intended to answer general questions about the platform, getting started, onboarding, and product capabilities using approved public knowledge sources. It does not provide access to private workspace information, audit answers, evidence, user details, payment details, or confidential organization data.

For account-specific help, use the authenticated workspace, contact the organization administrator, or contact Audito support. Always review the current Privacy Policy before registering or sharing information with the platform.

## Common questions

### Can I use Audito for supplier or external audits?

Yes. Audito can support supplier, partner, and external organization audit workflows where these features are enabled for the workspace. The organization structure and available features depend on the chosen configuration.

### Can I reuse a checklist?

Yes. Checklists are designed to be reusable so organizations can standardize recurring audit processes. Once assigned to an audit, changes should be carefully controlled to preserve the audit record.

### What is the difference between an auditor and an entity head?

An auditor performs assigned audits, records answers and evidence, and submits reports. An entity head reviews audit and CAP information for the assigned organization scope in read-only mode.

### Can I track an issue after an audit is completed?

Yes. Create a Corrective Action Plan for findings that need follow-up, assign a due date, record progress and evidence, then complete the CAP when the issue has been addressed.

### Where can I find help after I sign in?

Open **Settings → Help & Guidance** to see instructions tailored to your role. New administrators can also use the guided onboarding flow to set up the organization, users, checklists, and first audit.

