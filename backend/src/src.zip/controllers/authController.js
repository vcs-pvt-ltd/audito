/**
 * Auth Controller
 *
 * Handles registration, login, token refresh, and password management.
 *
 * Registration supports ALL entity types — each registers independently:
 *
 *   Customer account:     Customer | Buying Office | Supplier
 *   Company account:      Company | Cluster | Factory | Unit | Department
 *   Audit Firm account:   Audit Firm Company
 *
 * After registration, entities link to each other via organization_links.
 */

const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const AdminModel = require('../models/AdminModel');
const PromoCodeModel = require('../models/PromoCodeModel');
const AuditorModel = require('../models/AuditorModel');
const OrganizationUserModel = require('../models/OrganizationUserModel');
const CustomerModel = require('../models/CustomerModel');
const CompanyModel = require('../models/CompanyModel');
const AuditFirmModel = require('../models/AuditFirmModel');
const PrivacyPolicyModel = require('../models/PrivacyPolicyModel');
const {
  generateCustCode,
  generateCboCode,
  generateSupplierCode,
  generateCompCode,
  generateCompClusCode,
  generateCompFactCode,
  generateCompUnitCode,
  generateCompDeptCode,
  generateCompSectionCode,
  generateAfcCode,
  generateAfcBranchCode,
  generateAfcDeptCode,
  generateAdminUserCode,
  generateRefreshTokenId,
  generatePasswordResetOtpId
} = require('../utils/codeGenerator');
const { successResponse, errorResponse, validateRequiredFields, isValidEmail } = require('../utils/helpers');
const { db } = require('../config/db');
const crypto = require('crypto');
const { sendOrganizationRegistrationVerificationEmail, sendCustomSolutionVerificationEmail, sendCustomSolutionRequestEmail, sendUserInvitationEmail, sendOtpEmail } = require('../services/emailService');
const PaymentModel = require('../models/PaymentModel');
const { getOrgName, getOrgDetails, getCountryDialingCode } = require('../utils/orgLookup');
const { getResendCooldownSeconds, recordResend } = require('../utils/emailResendCooldown');
const SubscriptionModel = require('../models/SubscriptionModel');
const CustomSolutionModel = require('../models/CustomSolutionModel');
const PlanSettingsModel = require('../models/PlanSettingsModel');
const PromotionCampaignModel = require('../models/PromotionCampaignModel');
const fs = require('fs');
const path = require('path');

// ─── Entity type configuration ───────────────────────────────────
// Maps each entity_type to its account_type, org_level, code generator, and DB insert function.

const ENTITY_CONFIG = {
  'Customer': { account_type: 'Customer', org_level: 8, genCode: generateCustCode, table: 'customers', codeField: 'cust_code' },
  'Buying Office': { account_type: 'Customer', org_level: 7, genCode: generateCboCode, table: 'customer_buying_offices', codeField: 'cbo_code' },
  'Supplier': { account_type: 'Customer', org_level: 7, genCode: generateSupplierCode, table: 'customer_suppliers', codeField: 'csup_code' },
  'Company': { account_type: 'Company', org_level: 5, genCode: generateCompCode, table: 'companies', codeField: 'comp_code' },
  'Cluster': { account_type: 'Company', org_level: 4, genCode: generateCompClusCode, table: 'company_clusters', codeField: 'comp_clus_code' },
  'Factory': { account_type: 'Company', org_level: 3, genCode: generateCompFactCode, table: 'company_factories', codeField: 'comp_fact_code' },
  'Unit': { account_type: 'Company', org_level: 2, genCode: generateCompUnitCode, table: 'company_units', codeField: 'comp_unit_code' },
  'Department': { account_type: 'Company', org_level: 1, genCode: generateCompDeptCode, table: 'company_departments', codeField: 'comp_dept_code' },
  'Section': { account_type: 'Company', org_level: 1, genCode: generateCompSectionCode, table: 'company_sections', codeField: 'comp_section_code' },
  // Audit Firm: keep entity_type as "Audit Firm Company" (table: audit_firm_companies),
  // but normalize account_type to "Audit Firm" everywhere in auth/session.
  'Audit Firm Company': { account_type: 'Audit Firm', org_level: 6, genCode: generateAfcCode, table: 'audit_firm_companies', codeField: 'afc_code' },
  'Branch': { account_type: 'Audit Firm', org_level: 3, genCode: generateAfcBranchCode, table: 'audit_firm_company_branches', codeField: 'afc_branch_code' }
  ,
  'Audit Firm Department': { account_type: 'Audit Firm', org_level: 1, genCode: generateAfcDeptCode, table: 'audit_firm_company_departments', codeField: 'afc_dept_code' }
};

const VALID_ENTITY_TYPES = Object.keys(ENTITY_CONFIG);

const ORGANIZATION_LOGO_PREFIX = '/uploads/organization-logos/';
const MAX_ORGANIZATION_LOGO_BYTES = 700 * 1024;

const saveOrganizationLogo = (entityCode, base64Image) => {
  if (!base64Image) return null;

  const match = /^data:(image\/(?:png|jpeg));base64,([A-Za-z0-9+/=\s]+)$/i.exec(base64Image);
  if (!match) {
    throw new Error('Organization logo must be a PNG or JPEG image.');
  }

  const imageBuffer = Buffer.from(match[2].replace(/\s/g, ''), 'base64');
  if (!imageBuffer.length || imageBuffer.length > MAX_ORGANIZATION_LOGO_BYTES) {
    throw new Error('Organization logo must be 700 KB or smaller.');
  }

  const extension = match[1].toLowerCase() === 'image/jpeg' ? 'jpg' : 'png';
  const targetDir = path.join(__dirname, '..', 'public', 'uploads', 'organization-logos');
  fs.mkdirSync(targetDir, { recursive: true });

  const filename = `organization_${entityCode}_${Date.now()}_${crypto.randomBytes(6).toString('hex')}.${extension}`;
  fs.writeFileSync(path.join(targetDir, filename), imageBuffer, { flag: 'wx' });
  return `${ORGANIZATION_LOGO_PREFIX}${filename}`;
};

const deleteOrganizationLogo = (logoPath) => {
  if (!logoPath || !logoPath.startsWith(ORGANIZATION_LOGO_PREFIX)) return;
  const filename = path.basename(logoPath);
  const filePath = path.join(__dirname, '..', 'public', 'uploads', 'organization-logos', filename);
  if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
};

// Standard plans control the entity type that may start a workspace.
// Customer-family registrations require Elite. Company and Audit Firm entry
// points depend on the selected standard plan.
const PLAN_REGISTRATION_ENTITY_ACCESS = {
  Basic: ['Factory', 'Unit', 'Department', 'Audit Firm Department'],
  Pro: ['Cluster', 'Factory', 'Unit', 'Department', 'Branch', 'Audit Firm Department'],
  Elite: ['Customer', 'Buying Office', 'Supplier', 'Company', 'Cluster', 'Factory', 'Unit', 'Department', 'Audit Firm Company', 'Branch', 'Audit Firm Department']
};

// Helper: get entity code from admin (now just entity_code)
const getEntityCode = (admin) => admin.entity_code || null;

const normalizeUserRole = (role) => (
  role === 'entity_head' ? 'organization_user' : role
);

// ─── Generate JWT tokens (supports all roles) ────────────────────

const generateTokens = (admin) => generateTokensForRole('admin', admin);

function normalizeAccountType(accountType, entityType) {
  if (accountType === 'Audit Firm Company') return 'Audit Firm';
  // Safety: if legacy data has null account_type but entity_type is audit firm root
  if (!accountType && entityType === 'Audit Firm Company') return 'Audit Firm';
  return accountType;
}

function generateTokensForRole(role, record) {
  let payload;
  const actualRole = normalizeUserRole(record.role || role);

  if (actualRole === 'admin' || actualRole === 'audito_admin') {
    payload = {
      userId: record.admin_id,
      userCode: record.admin_id,
      email: record.email,
      role: actualRole,
      accountType: actualRole === 'audito_admin' ? 'audito_admin' : normalizeAccountType(record.account_type, record.entity_type),
      entityType: record.entity_type || null,
      entityCode: record.entity_code || null,
      orgLevel: record.org_level || 0,
    };
  } else if (actualRole === 'auditor') {
    payload = {
      userId: record.auditor_id,
      userCode: record.auditor_id,
      email: record.email,
      role: 'auditor',
      userType: record.user_type,
      auditorType: record.auditor_type || null,
      assignedEntityType: record.assigned_entity_type,
      assignedEntityCode: record.assigned_entity_code,
      createdByEntityCode: record.created_by_entity_code,
    };
  } else {
    // organization_user
    payload = {
      userId: record.organization_user_id,
      userCode: record.organization_user_id,
      email: record.email,
      role: 'organization_user',
      userType: record.user_type,
      assignedEntityType: record.assigned_entity_type,
      assignedEntityCode: record.assigned_entity_code,
      createdByEntityCode: record.created_by_entity_code,
    };
  }

  const accessToken = jwt.sign(payload, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '24h',
  });

  const refreshToken = jwt.sign(
    { userId: payload.userId, userCode: payload.userCode, role: actualRole },
    process.env.JWT_REFRESH_SECRET,
    { expiresIn: '7d' }
  );

  return { accessToken, refreshToken };
}

// ─── Helpers: build user response & collect accounts ─────────────

function buildUserResponse(role, record) {
  const actualRole = normalizeUserRole(record.role || role);
  if (actualRole === 'admin' || actualRole === 'audito_admin') {
    return {
      id: record.admin_id,
      first_name: record.first_name,
      last_name: record.last_name,
      email: record.email,
      phone_number: record.phone_number || null,
      country: record.country || null,
      role: actualRole,
      account_type: actualRole === 'audito_admin' ? 'audito_admin' : normalizeAccountType(record.account_type, record.entity_type),
      entity_type: record.entity_type || null,
      entity_code: record.entity_code || null,
      org_level: record.org_level || 0,
      user_type: null,
      assigned_entity_type: null,
      assigned_entity_code: null,
      created_by_entity_code: null,
      onboarding_completed: !!record.onboarding_completed,
      onboarding_skipped: !!record.onboarding_skipped,
      onboarding_completed_at: record.onboarding_completed_at || null,
      profile_image: record.profile_image || null,
    };
  }
  // auditor or organization_user
  return {
    id: role === 'auditor' ? record.auditor_id : record.organization_user_id,
    first_name: record.first_name,
    last_name: record.last_name,
    email: record.email,
    phone_number: record.phone_number || null,
    country: record.country || null,
    role,
    account_type: null,
    entity_type: record.assigned_entity_type || null,
    entity_code: role === 'organization_user'
      ? (record.assigned_entity_code || record.created_by_entity_code)
      : record.created_by_entity_code,
    org_level: 0,
    user_type: record.user_type,
    auditor_type: record.auditor_type || null,
    assigned_entity_type: record.assigned_entity_type || null,
    assigned_entity_code: record.assigned_entity_code || null,
    assigned_org_tree_id: role === 'organization_user' ? (record.assigned_org_tree_id || null) : null,
    created_by_entity_code: record.created_by_entity_code,
    onboarding_completed: !!record.onboarding_completed,
    onboarding_skipped: !!record.onboarding_skipped,
    onboarding_completed_at: record.onboarding_completed_at || null,
    profile_image: record.profile_image || null,
  };
}

function getRootEntityCode(role, record) {
  if (role === 'audito_admin') return null;
  return role === 'admin' ? record.entity_code : record.created_by_entity_code;
}

async function getPlanLimitsForUser(role, record) {
  const rootCode = getRootEntityCode(role, record);
  if (!rootCode) return await SubscriptionModel.getPlanLimits('Basic');
  return await SubscriptionModel.getLimits(rootCode);
}

/**
 * Identifies whether the user's organization plan has expired and updates the
 * subscription accordingly. Deactivates any expired row (so limits fall back to
 * Basic), then returns the latest status for the client to surface a renewal prompt.
 */
async function resolveSubscriptionStatus(role, record) {
  const rootCode = getRootEntityCode(role, record);
  if (!rootCode) {
    return { has_subscription: false, plan_name: 'Basic', billing_cycle: null, start_date: null, end_date: null, is_active: false, is_expired: false };
  }
  await SubscriptionModel.deactivateExpired(rootCode);
  return await SubscriptionModel.getStatus(rootCode);
}

async function collectAccounts(email) {
  const accounts = [];

  const admin = await AdminModel.findByEmail(email);
  if (admin && admin.is_active) {
    const actualRole = admin.role || 'admin';
    accounts.push({
      role: actualRole,
      user_code: admin.admin_id,
      first_name: admin.first_name,
      last_name: admin.last_name,
      account_type: actualRole === 'audito_admin' ? 'audito_admin' : normalizeAccountType(admin.account_type, admin.entity_type),
      entity_type: admin.entity_type || null,
      entity_code: admin.entity_code || null,
      org_level: admin.org_level || 0,
      user_type: null,
    });
  }

  const auditor = await AuditorModel.findByEmail(email);
  if (auditor && auditor.is_active && auditor.email_verified && auditor.password) {
    accounts.push({
      role: 'auditor',
      user_code: auditor.auditor_id,
      first_name: auditor.first_name,
      last_name: auditor.last_name,
      account_type: null,
      entity_type: auditor.assigned_entity_type || null,
      entity_code: auditor.created_by_entity_code,
      org_level: 0,
      user_type: auditor.user_type,
      auditor_type: auditor.auditor_type || null,
    });
  }

  const organizationUser = await OrganizationUserModel.findByEmail(email);
  if (organizationUser && organizationUser.is_active && organizationUser.email_verified && organizationUser.password) {
    accounts.push({
      role: 'organization_user',
      user_code: organizationUser.organization_user_id,
      first_name: organizationUser.first_name,
      last_name: organizationUser.last_name,
      account_type: null,
      entity_type: organizationUser.assigned_entity_type || null,
      entity_code: organizationUser.assigned_entity_code || organizationUser.created_by_entity_code,
      org_level: 0,
      user_type: organizationUser.user_type,
    });
  }

  return accounts;
}

// ─── REGISTER ────────────────────────────────────────────────────

/**
 * POST /api/auth/register
 *
 * Registers any entity type independently and creates its admin user.
 *
 * Standard plans require an administrator. Custom plans verify the organization
 * email first and collect administrator details after price approval, before payment.
 * Optional: registration_number, org_email, address, country, org_phone_number, nic, phone_number
 *
 * entity_type: Customer | Buying Office | Supplier | Company | Cluster | Factory |
 *              Unit | Department | Audit Firm Company
 */
const register = async (req, res) => {
  const connection = await db.getConnection();
  let savedOrganizationLogoPath = null;

  try {
    const {
      entity_type,
      org_name,
      registration_number,
      org_email,
      address,
      country,
      org_phone_number,
      first_name,
      last_name,
      email,
      phone_number,
      company_type,
      password,
      plan_name,
      billing_cycle,
      timezone,
      promo_code,
      custom_solution,
      organization_logo,
      privacy_policy_id
    } = req.body;

    const isCustomPlan = plan_name === 'Custom';
    const customOnlyEntityTypes = new Set([
      'Customer', 'Buying Office', 'Supplier',
      'Audit Firm Company', 'Branch', 'Audit Firm Department',
    ]);
    const missing = validateRequiredFields(req.body, isCustomPlan
      ? ['entity_type', 'org_name', 'org_email', 'plan_name', 'custom_solution']
      : ['entity_type', 'org_name', 'first_name', 'last_name', 'email', 'password', 'plan_name']);
    if (missing) return errorResponse(res, missing, 400);

    const activePrivacyPolicy = await PrivacyPolicyModel.getPublished();
    if (!activePrivacyPolicy) return errorResponse(res, 'Registration is temporarily unavailable because no privacy policy has been published.', 503);
    if (!privacy_policy_id || privacy_policy_id !== activePrivacyPolicy.privacy_policy_id) {
      return errorResponse(res, 'Please review and agree to the current Privacy Policy before registering.', 400);
    }

    if (!isCustomPlan && customOnlyEntityTypes.has(entity_type)) {
      return errorResponse(res, 'Customer and Audit Firm workspaces require a Custom plan.', 400);
    }

    // Validate promo code if provided
    let discount = 0;
    if (promo_code) {
      const promo = await PromoCodeModel.findByCode(promo_code);
      if (!promo) {
        return errorResponse(res, 'Invalid or expired promo code.', 400);
      }
      discount = parseFloat(promo.discount_percentage);
    }

    if (!VALID_ENTITY_TYPES.includes(entity_type)) {
      return errorResponse(
        res,
        `Invalid entity_type. Allowed: ${VALID_ENTITY_TYPES.join(', ')}`,
        400
      );
    }

    const normalizedPlanName = SubscriptionModel.normalizePlanName(plan_name);
    if (!isCustomPlan) {
      const planSettings = await PlanSettingsModel.find(normalizedPlanName);
      if (!planSettings?.is_active) return errorResponse(res, 'The selected plan is not currently available.', 409);
    }
    const registrationEntityAccess = PLAN_REGISTRATION_ENTITY_ACCESS[normalizedPlanName] || PLAN_REGISTRATION_ENTITY_ACCESS.Elite;
    if (plan_name !== 'Custom' && !registrationEntityAccess?.includes(entity_type)) {
      return errorResponse(
        res,
        `${normalizedPlanName} does not include ${entity_type} as a workspace entry type. Choose an available type or upgrade the plan.`,
        403
      );
    }

    const registrationEmail = isCustomPlan ? org_email : email;
    if (!isValidEmail(registrationEmail)) return errorResponse(res, 'Invalid email address.', 400);

    if (!isCustomPlan) {
      // Strong password validation: min 8 chars, 1 uppercase, 1 lowercase, 1 number, 1 special char
      const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&#])[A-Za-z\d@$!%*?&#]{8,}$/;
      if (!passwordRegex.test(password)) {
        return errorResponse(res, 'Password must be at least 8 characters long and include at least one uppercase letter, one lowercase letter, one number, and one special character.', 400);
      }
    }

    // Custom requests do not create an admin yet. Standard registrations still
    // reserve the administrator email immediately.
    if (!isCustomPlan && await AdminModel.emailExists(email)) {
      return errorResponse(res, 'Email already registered.', 409);
    }

    // Check duplicate registration number in the specific entity table
    if (registration_number) {
      const config = ENTITY_CONFIG[entity_type];
      const [existing] = await db.query(
        `SELECT id FROM \`${config.table}\` WHERE registration_number = ?`,
        [registration_number]
      );
      if (existing.length > 0) {
        return errorResponse(res, 'Registration number already exists for this entity type.', 409);
      }
    }

    // Generate entity code. Admin credentials are intentionally deferred for custom plans.
    const config = ENTITY_CONFIG[entity_type];
    const orgCode = await config.genCode();
    const userCode = isCustomPlan ? null : await generateAdminUserCode();
    const hashedPw = isCustomPlan ? null : await bcrypt.hash(password, await bcrypt.genSalt(12));

    // Transaction: insert entity + admin
    await connection.beginTransaction();

    // Build the org insert - all entity tables share the same base columns
    const orgData = {
      name: org_name,
      registration_number: registration_number || null,
      email: org_email || null,
      address_line_1: req.body.address_line_1 || null,
      address_line_2: req.body.address_line_2 || null,
      address_line_3: req.body.address_line_3 || null,
      country: country || null,
      phone_number: org_phone_number || null,
      company_type: entity_type === 'Company' ? (company_type || null) : null,
      organization_logo: null
    };

    if (organization_logo) {
      try {
        orgData.organization_logo = saveOrganizationLogo(orgCode, organization_logo);
        savedOrganizationLogoPath = orgData.organization_logo;
      } catch (logoError) {
        return errorResponse(res, logoError.message, 400);
      }
    }

    if (entity_type === 'Company') {
      await connection.query(
        `INSERT INTO \`${config.table}\` (name, registration_number, email, address_line_1, address_line_2, address_line_3, country, phone_number, \`${config.codeField}\`, company_type, timezone, organization_logo)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [orgData.name, orgData.registration_number, orgData.email,
        orgData.address_line_1, orgData.address_line_2, orgData.address_line_3,
        orgData.country, orgData.phone_number, orgCode, orgData.company_type, timezone || null, orgData.organization_logo]
      );
    } else {
      await connection.query(
        `INSERT INTO \`${config.table}\` (name, registration_number, email, address_line_1, address_line_2, address_line_3, country, phone_number, \`${config.codeField}\`, timezone, organization_logo)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [orgData.name, orgData.registration_number, orgData.email,
        orgData.address_line_1, orgData.address_line_2, orgData.address_line_3,
        orgData.country, orgData.phone_number, orgCode, timezone || null, orgData.organization_logo]
      );
    }

    // Insert admin with generic entity_code
    const adminId = isCustomPlan ? null : await AdminModel.create({
      admin_id: userCode,
      first_name,
      last_name,
      email,
      country: country || null,
      phone_number: phone_number || null,
      password: hashedPw,
      account_type: config.account_type,
      entity_type,
      entity_code: orgCode,
      org_level: config.org_level
    });

    // Free plans are activated immediately. Paid plans defer the subscription
    // until payment is confirmed — until then limits fall back to Basic.
    // Custom plans are also deferred until admin assigns a price.
    // Basic starts with one free month. Its configured monthly price is used
    // only when this subscription renews after that trial period.
    const effectiveBillingCycle = normalizedPlanName === 'Basic' ? 'Monthly' : billing_cycle;
    let planAmount = isCustomPlan ? 0 : await SubscriptionModel.computeAmount(plan_name, effectiveBillingCycle, entity_type);
    const listAmount = planAmount;
    // Campaigns are automatic and never combine with a manually-entered promo
    // code. A valid promo code keeps its established behaviour and takes
    // precedence over an automatic promotion.
    const campaignOffer = !isCustomPlan && !promo_code && normalizedPlanName !== 'Basic'
      ? await PromotionCampaignModel.resolveBestOffer({
        planName: normalizedPlanName,
        billingCycle: effectiveBillingCycle === 'Yearly' ? 'Yearly' : 'Monthly',
        purpose: 'registration',
        listAmount,
      })
      : null;
    if (normalizedPlanName === 'Basic') planAmount = 0;
    const customVerificationToken = isCustomPlan ? crypto.randomBytes(32).toString('hex') : null;
    if (campaignOffer) {
      planAmount = campaignOffer.final_amount;
    } else if (discount > 0) {
      planAmount = planAmount * (1 - discount / 100);
      planAmount = Math.max(0, parseFloat(planAmount.toFixed(2)));
    }
    if (!isCustomPlan && planAmount <= 0) {
      await SubscriptionModel.createSubscription(connection, orgCode, normalizedPlanName, effectiveBillingCycle);
    }

    // For custom plans, store the custom solution request
    if (isCustomPlan && custom_solution) {
      const customLimits = await SubscriptionModel.normalizeCustomLimits({
        company_level: custom_solution.max_company_levels,
        department: custom_solution.max_departments,
        audits: custom_solution.max_audits,
        checklists: custom_solution.max_checklists,
        auditors: custom_solution.max_auditors,
        auditor_eval: custom_solution.allow_auditor_eval,
        company_to_company: custom_solution.allow_company_to_company,
      });
      await CustomSolutionModel.create({
        root_entity_code: orgCode,
        admin_id: adminId,
        org_name,
        org_email,
        entity_type,
        max_company_levels: customLimits.company_level,
        max_departments: customLimits.department,
        max_audits: customLimits.audits,
        max_checklists: customLimits.checklists,
        max_auditors: customLimits.auditors,
        allow_auditor_eval: customLimits.auditor_eval,
        allow_company_to_company: customLimits.company_to_company,
        verification_token: customVerificationToken,
        verification_expires_at: new Date(Date.now() + 48 * 60 * 60 * 1000),
      }, connection);
    }

    await PrivacyPolicyModel.recordAgreement(connection, {
      privacyPolicyId: activePrivacyPolicy.privacy_policy_id,
      adminId,
      rootEntityCode: orgCode,
      email: registrationEmail,
      ipAddress: req.ip,
      userAgent: req.get('user-agent'),
    });

    await connection.commit();

    if (isCustomPlan) {
      sendCustomSolutionVerificationEmail(org_email, org_name, customVerificationToken).catch(err => {
        console.error('Failed to send custom solution verification email:', err);
      });
      recordResend(`verification:${org_email}`);
      return successResponse(res, { custom_solution_pending: true }, 'Custom solution request created. Please verify the organization email to send it for pricing review.', 201);
    }

    // Generate Verification Token and Send Email
    const verificationToken = crypto.randomBytes(32).toString('hex');
    await AdminModel.setVerificationToken(adminId, verificationToken);

    // Dispatch email
    sendOrganizationRegistrationVerificationEmail(email, first_name, verificationToken, org_name).catch(err => {
      console.error('Failed to send organization verification email:', err);
    });
    recordResend(`verification:${email}`);

    // For a paid plan, create the pending registration payment so the client
    // can redirect into the payment flow.
    let payment = null;
    if (planAmount > 0) {
      const created = await PaymentModel.create({
        rootEntityCode: orgCode,
        purpose: 'registration',
        planName: SubscriptionModel.normalizePlanName(plan_name),
        billingCycle: billing_cycle === 'Yearly' ? 'Yearly' : 'Monthly',
        amount: planAmount,
        payerName: `${first_name} ${last_name}`,
        payerEmail: email,
        orgName: org_name,
        promotionCampaignId: campaignOffer?.campaign_id || null,
        listAmount,
        promotionDiscountAmount: campaignOffer?.discount_amount || 0,
      });
      payment = {
        payment_code: created.payment_code,
        plan_name: created.plan_name,
        billing_cycle: created.billing_cycle,
        amount: Number(created.amount),
        currency: created.currency,
      };
    }

    return successResponse(res, { payment }, 'Registration successful. Please check your email to verify your account.', 201);

  } catch (error) {
    await connection.rollback();
    deleteOrganizationLogo(savedOrganizationLogoPath);
    console.error('Registration error:', error);
    return errorResponse(res, 'Registration failed. Please try again.', 500);
  } finally {
    connection.release();
  }
};

// ─── LOGIN ───────────────────────────────────────────────────────

/**
 * POST /api/auth/login
 * Body: { email, password, preferred_role? }
 *
 * Unified login — checks admins, auditors, and organization_users tables.
 * If the email exists in multiple tables, returns all available accounts
 * and logs into the first one whose password matches. A previous-role preference
 * may be supplied by the client, but it never bypasses password verification.
 */
const login = async (req, res) => {
  try {
    const { email, password, preferred_role: preferredRole } = req.body;

    const missing = validateRequiredFields(req.body, ['email', 'password']);
    if (missing) return errorResponse(res, missing, 400);

    // Find the email in all 3 tables
    const adminRec = await AdminModel.findByEmail(email);
    const auditorRec = await AuditorModel.findByEmail(email);
    const organizationUserRecord = await OrganizationUserModel.findByEmail(email);

    // A custom-plan administrator is created before checkout but intentionally
    // stays inactive until payment succeeds. If checkout was cancelled, allow
    // the correct password to resume that existing payment instead of treating
    // the account as invalid or creating another administrator.
    if (adminRec && !adminRec.is_active && adminRec.is_verified && adminRec.password) {
      const customRequest = await CustomSolutionModel.findByOrgCode(adminRec.entity_code);
      if (customRequest?.admin_setup_completed && customRequest.admin_id === adminRec.admin_id && customRequest.payment_code) {
        const payment = await PaymentModel.findByCode(customRequest.payment_code);
        if (payment && ['pending', 'failed'].includes(payment.status) && await bcrypt.compare(password, adminRec.password)) {
          return successResponse(
            res,
            {
              payment_required: true,
              payment: {
                payment_code: payment.payment_code,
                plan_name: payment.plan_name,
                billing_cycle: payment.billing_cycle,
                amount: Number(payment.amount),
                currency: payment.currency,
              },
            },
            'Your administrator account is ready. Please complete payment to activate the workspace.'
          );
        }
      }
    }

    // Build candidate list — { role, record } — with password-check candidates
    const candidates = [];
    const unverifiedCandidates = [];
    if (adminRec && adminRec.is_active && adminRec.password) {
      if (adminRec.is_verified) candidates.push({ role: adminRec.role || 'admin', record: adminRec });
      else unverifiedCandidates.push({ role: adminRec.role || 'admin', record: adminRec });
    }
    if (organizationUserRecord && organizationUserRecord.is_active && organizationUserRecord.password) {
      if (organizationUserRecord.email_verified) candidates.push({ role: 'organization_user', record: organizationUserRecord });
      else unverifiedCandidates.push({ role: 'organization_user', record: organizationUserRecord });
    }
    if (auditorRec && auditorRec.is_active && auditorRec.password) {
      if (auditorRec.email_verified) candidates.push({ role: 'auditor', record: auditorRec });
      else unverifiedCandidates.push({ role: 'auditor', record: auditorRec });
    }

    // A user can legitimately have more than one account role under the same
    // email address. Prefer the last role they used when it is available, while
    // retaining the existing fallback order and password checks for every role.
    if (typeof preferredRole === 'string' && preferredRole.trim()) {
      const normalizedPreferredRole = normalizeUserRole(preferredRole.trim());
      candidates.sort((a, b) => {
        if (a.role === normalizedPreferredRole) return -1;
        if (b.role === normalizedPreferredRole) return 1;
        return 0;
      });
    }

    // Try the given password against each candidate in the preferred order.
    let activeRole = null;
    let activeRecord = null;
    for (const c of candidates) {
      if (await bcrypt.compare(password, c.record.password)) {
        activeRole = c.role;
        activeRecord = c.record;
        break;
      }
    }

    if (!activeRole) {
      for (const candidate of unverifiedCandidates) {
        if (await bcrypt.compare(password, candidate.record.password)) {
          return successResponse(
            res,
            { email_verification_required: true, email: candidate.record.email },
            'Please verify your email address before signing in.'
          );
        }
      }
      return errorResponse(res, 'Invalid email or password.', 401);
    }

    // Block login when the organization's plan has expired. Credentials are
    // already verified above, so this only reveals expiry to the real account
    // owner. Returned as a 200 with a `subscription_expired` flag (no tokens) so
    // the browser doesn't log a network error for this expected, handled case;
    // the client uses the flag to show a renew modal instead of signing in.
    const subscription = await resolveSubscriptionStatus(activeRole, activeRecord);
    if (subscription.is_expired) {
      // Prepare a renewal payment so the client can route into the payment flow.
      // Reuse an existing pending renewal to avoid spawning duplicates per attempt.
      let payment = null;
      const renewalListAmount = await SubscriptionModel.computeAmount(subscription.plan_name, subscription.billing_cycle, activeRecord.entity_type);
      const renewalOffer = await PromotionCampaignModel.resolveBestOffer({
        planName: SubscriptionModel.normalizePlanName(subscription.plan_name),
        billingCycle: subscription.billing_cycle === 'Yearly' ? 'Yearly' : 'Monthly',
        purpose: 'renewal',
        listAmount: renewalListAmount,
      });
      const renewalAmount = renewalOffer?.final_amount ?? renewalListAmount;
      if (renewalAmount > 0) {
        const rootCode = getRootEntityCode(activeRole, activeRecord);
        let pending = await PaymentModel.findPendingByOrgPurpose(rootCode, 'renewal');
        if (!pending) {
          const orgName = activeRole === 'admin'
            ? await getOrgName(activeRecord.entity_type, activeRecord.entity_code)
            : null;
          pending = await PaymentModel.create({
            rootEntityCode: rootCode,
            purpose: 'renewal',
            planName: SubscriptionModel.normalizePlanName(subscription.plan_name),
            billingCycle: subscription.billing_cycle === 'Yearly' ? 'Yearly' : 'Monthly',
            amount: renewalAmount,
            payerName: `${activeRecord.first_name} ${activeRecord.last_name}`,
            payerEmail: activeRecord.email,
            orgName,
            promotionCampaignId: renewalOffer?.campaign_id || null,
            listAmount: renewalListAmount,
            promotionDiscountAmount: renewalOffer?.discount_amount || 0,
          });
        }
        payment = {
          payment_code: pending.payment_code,
          plan_name: pending.plan_name,
          billing_cycle: pending.billing_cycle,
          amount: Number(pending.amount),
          currency: pending.currency,
        };
      }

      return successResponse(
        res,
        { subscription_expired: true, subscription, payment },
        'Your subscription has expired. Please renew to continue.'
      );
    }

    // Block login if the registration payment was never completed (paid plan
    // registered but not yet paid). Route the admin into the payment flow.
    if (activeRole === 'admin') {
      const pendingReg = await PaymentModel.findPendingByOrgPurpose(activeRecord.entity_code, 'registration');
      if (pendingReg) {
        return successResponse(
          res,
          {
            payment_required: true,
            payment: {
              payment_code: pendingReg.payment_code,
              plan_name: pendingReg.plan_name,
              billing_cycle: pendingReg.billing_cycle,
              amount: Number(pendingReg.amount),
              currency: pendingReg.currency,
            },
          },
          'Please complete your subscription payment to continue.'
        );
      }

      // Check if custom solution has been priced — route to payment
      const customPriced = await CustomSolutionModel.findByOrgCode(activeRecord.entity_code);
      if (customPriced && customPriced.status === 'priced' && customPriced.payment_code) {
        const customPayment = await PaymentModel.findByCode(customPriced.payment_code);
        if (customPayment && customPayment.status === 'pending') {
          return successResponse(
            res,
            {
              payment_required: true,
              payment: {
                payment_code: customPayment.payment_code,
                plan_name: 'Custom',
                billing_cycle: customPayment.billing_cycle,
                amount: Number(customPayment.amount),
                currency: customPayment.currency,
              },
            },
            'Your custom plan is ready. Please complete payment to continue.'
          );
        }
      }

      // Check if custom solution is still pending admin review
      const customPending = await CustomSolutionModel.findByOrgCodePending(activeRecord.entity_code);
      if (customPending) {
        return successResponse(
          res,
          { custom_solution_pending: true },
          'Your custom solution request is being reviewed. We will notify you via email once pricing is ready.'
        );
      }
    }

    // Generate tokens for the matched account
    const tokens = generateTokensForRole(activeRole, activeRecord);

    // Store refresh token
    const refreshExpiry = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
    const recordId = activeRole === 'admin' || activeRole === 'audito_admin'
      ? activeRecord.admin_id
      : activeRole === 'auditor'
        ? activeRecord.auditor_id
        : activeRecord.organization_user_id;
        const refreshTokenId = await generateRefreshTokenId();

    await db.query(
      'INSERT INTO refresh_tokens (refresh_token_id, admin_id, user_role, token, expires_at) VALUES (?, ?, ?, ?, ?)',
      [refreshTokenId, recordId, activeRole, tokens.refreshToken, refreshExpiry]
    );

    if (activeRole === 'admin') {
      await AdminModel.updateLastLogin(recordId);
    }

    // Collect ALL available accounts for this email (regardless of password match)
    const accounts = await collectAccounts(email);

    // Fetch plan limits (subscription already resolved & verified non-expired above)
    const plan_limits = await getPlanLimitsForUser(activeRole, activeRecord);

    return successResponse(res, {
      admin: { ...buildUserResponse(activeRole, activeRecord), plan_limits },
      accounts,
      subscription,
      tokens,
    }, 'Login successful.');

  } catch (error) {
    console.error('Login error:', error);
    return errorResponse(res, 'Login failed. Please try again.', 500);
  }
};

// ─── REFRESH TOKEN ────────────────────────────────────────────────

/**
 * POST /api/auth/refresh-token
 * Body: { refresh_token }
 */
const refreshToken = async (req, res) => {
  try {
    const { refresh_token } = req.body;
    if (!refresh_token) return errorResponse(res, 'Refresh token is required.', 400);

    const decoded = jwt.verify(refresh_token, process.env.JWT_REFRESH_SECRET);

    const role = normalizeUserRole(decoded.role || 'admin');
    const userId = decoded.userId || decoded.adminId;  // backward compat

    const [rows] = await db.query(
      'SELECT * FROM refresh_tokens WHERE admin_id = ? AND token = ? AND expires_at > NOW()',
      [userId, refresh_token]
    );
    if (rows.length === 0) return errorResponse(res, 'Invalid or expired refresh token.', 401);

    let record;
    if (role === 'admin' || role === 'audito_admin') {
      record = await AdminModel.findById(userId);
    } else if (role === 'auditor') {
      record = await AuditorModel.findById(userId);
    } else if (role === 'organization_user') {
      record = await OrganizationUserModel.findById(userId);
    }
    if (!record || !record.is_active) return errorResponse(res, 'Account not found or deactivated.', 401);

    await db.query('DELETE FROM refresh_tokens WHERE token = ?', [refresh_token]);

    const tokens = generateTokensForRole(role, record);

    const refreshExpiry = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
    const recordId = role === 'admin' || role === 'audito_admin'
      ? record.admin_id
      : role === 'auditor'
        ? record.auditor_id
        : record.organization_user_id;
const refreshTokenId = await generateRefreshTokenId();

    await db.query(
      'INSERT INTO refresh_tokens (refresh_token_id, admin_id, user_role, token, expires_at) VALUES (?, ?, ?, ?, ?)',
      [refreshTokenId, recordId, role, tokens.refreshToken, refreshExpiry]
    );

    return successResponse(res, { tokens }, 'Token refreshed.');

  } catch (error) {
    if (error.name === 'TokenExpiredError') return errorResponse(res, 'Refresh token expired.', 401);
    if (error.name === 'JsonWebTokenError') return errorResponse(res, 'Invalid refresh token.', 401);
    console.error('Refresh token error:', error);
    return errorResponse(res, 'Token refresh failed.', 500);
  }
};

// ─── LOGOUT ──────────────────────────────────────────────────────

/**
 * POST /api/auth/logout
 * Body: { refresh_token }
 */
const logout = async (req, res) => {
  try {
    const { refresh_token } = req.body;
    if (refresh_token) {
      await db.query('DELETE FROM refresh_tokens WHERE token = ?', [refresh_token]);
    }
    return successResponse(res, null, 'Logged out successfully.');
  } catch (error) {
    console.error('Logout error:', error);
    return errorResponse(res, 'Logout failed.', 500);
  }
};

// ─── GET ME ──────────────────────────────────────────────────────

/**
 * GET /api/auth/me
 * Returns the logged-in user's profile (works for all roles).
 */
const getMe = async (req, res) => {
  try {
    const role = req.user.role;
    const email = req.user.email;
    let userResponse, organization = null;

    if (role === 'admin' || role === 'audito_admin') {
      const admin = await AdminModel.findById(req.user.userCode);
      if (!admin) return errorResponse(res, 'Admin not found.', 404);
      userResponse = buildUserResponse(role, admin);

      const config = ENTITY_CONFIG[admin.entity_type];
      if (config) {
        const [orgRows] = await db.query(
          `SELECT name, registration_number, email, address_line_1, address_line_2, address_line_3, country, phone_number, organization_logo FROM \`${config.table}\` WHERE \`${config.codeField}\` = ?`,
          [admin.entity_code]
        );
        if (orgRows.length > 0) {
          organization = {
            ...orgRows[0],
            code: admin.entity_code,
            entity_type: admin.entity_type,
            account_type: admin.account_type,
            org_level: admin.org_level,
          };
        }
      }
    } else if (role === 'auditor') {
      const auditor = await AuditorModel.findById(req.user.userCode);
      if (!auditor) return errorResponse(res, 'Auditor not found.', 404);
      userResponse = buildUserResponse('auditor', auditor);
    } else if (role === 'organization_user') {
      const organizationUser = await OrganizationUserModel.findById(req.user.userCode);
      if (!organizationUser) return errorResponse(res, 'Organization user not found.', 404);
      userResponse = buildUserResponse('organization_user', organizationUser);
    } else {
      return errorResponse(res, 'Invalid role.', 400);
    }

    // Collect available accounts for this email
    const accounts = await collectAccounts(email);

    // Fetch plan limits
    const record = (role === 'admin' || role === 'audito_admin') ? await AdminModel.findById(req.user.userCode) :
      role === 'auditor' ? await AuditorModel.findById(req.user.userCode) :
        await OrganizationUserModel.findById(req.user.userCode);

    // Identify & handle plan expiry first so plan limits reflect any downgrade.
    const subscription = await resolveSubscriptionStatus(role, record);
    const plan_limits = await getPlanLimitsForUser(role, record);

    return successResponse(res, {
      admin: { ...userResponse, plan_limits },
      organization,
      accounts,
      subscription
    });
  } catch (error) {
    console.error('Get me error:', error);
    return errorResponse(res, 'Failed to fetch profile.', 500);
  }
};

/**
 * PUT /api/auth/organization
 * Body: { name, registration_number, email, address, country, phone_number, organization_logo }
 * Only works for 'admin' role on their own organization.
 */
const updateOrganization = async (req, res) => {
  let newLogoPath = null;
  try {
    if (req.user.role !== 'admin') {
      return errorResponse(res, 'Only administrators can update organization details.', 403);
    }

    const { name, registration_number, email, address_line_1, address_line_2, address_line_3, country, phone_number, organization_logo } = req.body;
    if (!name) return errorResponse(res, 'Organization name is required.', 400);

    const admin = await AdminModel.findById(req.user.userCode);
    if (!admin) return errorResponse(res, 'Admin not found.', 404);

    const config = ENTITY_CONFIG[admin.entity_type];
    if (!config) return errorResponse(res, 'Invalid entity type configuration.', 400);

    const [existingRows] = await db.query(
      `SELECT organization_logo FROM \`${config.table}\` WHERE \`${config.codeField}\` = ? LIMIT 1`,
      [admin.entity_code]
    );
    if (!existingRows.length) return errorResponse(res, 'Organization not found.', 404);

    const currentLogo = existingRows[0].organization_logo || null;
    const hasLogoUpdate = Object.prototype.hasOwnProperty.call(req.body, 'organization_logo');
    let finalLogo = currentLogo;
    if (hasLogoUpdate) {
      if (organization_logo === null || organization_logo === '') {
        finalLogo = null;
      } else if (typeof organization_logo === 'string' && organization_logo.startsWith('data:image/')) {
        try {
          newLogoPath = saveOrganizationLogo(admin.entity_code, organization_logo);
          finalLogo = newLogoPath;
        } catch (logoError) {
          return errorResponse(res, logoError.message, 400);
        }
      } else if (organization_logo !== currentLogo) {
        return errorResponse(res, 'Invalid organization logo.', 400);
      }
    }

    await db.query(
      `UPDATE \`${config.table}\` 
       SET name = ?, registration_number = ?, email = ?, address_line_1 = ?, address_line_2 = ?, address_line_3 = ?, country = ?, phone_number = ?, organization_logo = ? 
       WHERE \`${config.codeField}\` = ?`,
      [name, registration_number || null, email || null, address_line_1 || null, address_line_2 || null, address_line_3 || null, country || null, phone_number || null, finalLogo, admin.entity_code]
    );

    if (currentLogo && currentLogo !== finalLogo) deleteOrganizationLogo(currentLogo);

    return successResponse(res, null, 'Organization details updated successfully.');
  } catch (error) {
    deleteOrganizationLogo(newLogoPath);
    console.error('Update organization error:', error);
    return errorResponse(res, 'Failed to update organization details.', 500);
  }
};

// ─── CHANGE PASSWORD ─────────────────────────────────────────────

/**
 * PUT /api/auth/change-password
 * Body: { current_password, new_password }
 * Works for all roles.
 */
const changePassword = async (req, res) => {
  try {
    const { current_password, new_password } = req.body;

    const missing = validateRequiredFields(req.body, ['current_password', 'new_password']);
    if (missing) return errorResponse(res, missing, 400);
    if (new_password.length < 8) return errorResponse(res, 'New password must be at least 8 characters.', 400);

    const role = req.user.role;
    let record;

    if (role === 'admin' || role === 'audito_admin') {
      record = await AdminModel.findByEmail(req.user.email);
    } else if (role === 'auditor') {
      record = await AuditorModel.findByEmail(req.user.email);
    } else if (role === 'organization_user') {
      record = await OrganizationUserModel.findByEmail(req.user.email);
    }
    if (!record) return errorResponse(res, 'User not found.', 404);

    const isMatch = await bcrypt.compare(current_password, record.password);
    if (!isMatch) return errorResponse(res, 'Current password is incorrect.', 400);

    const salt = await bcrypt.genSalt(12);
    const hashedPassword = await bcrypt.hash(new_password, salt);

    if (role === 'admin' || role === 'audito_admin') {
      await AdminModel.updatePassword(record.admin_id, hashedPassword);
    } else if (role === 'auditor') {
      await AuditorModel.setPassword(record.auditor_id, hashedPassword);
    } else if (role === 'organization_user') {
      await OrganizationUserModel.setPassword(record.organization_user_id, hashedPassword);
    }

    return successResponse(res, null, 'Password changed successfully.');
  } catch (error) {
    console.error('Change password error:', error);
    return errorResponse(res, 'Failed to change password.', 500);
  }
};

// ─── SWITCH ACCOUNT ──────────────────────────────────────────────

/**
 * POST /api/auth/switch-account
 * Body: { target_role: 'admin'|'auditor'|'organization_user', password }
 *
 * Switches the active session to a different role's account.
 * Requires the password for the target account (may differ per role).
 */
const switchAccount = async (req, res) => {
  try {
    const { target_role: requestedTargetRole, password } = req.body;
    const target_role = normalizeUserRole(requestedTargetRole);

    if (!requestedTargetRole || !password) {
      return errorResponse(res, 'target_role and password are required.', 400);
    }
    if (!['admin', 'auditor', 'organization_user'].includes(target_role)) {
      return errorResponse(res, 'Invalid target_role.', 400);
    }

    // Derive email from the current session
    const email = req.user.email;

    let record;
    if (target_role === 'admin') {
      record = await AdminModel.findByEmail(email);
      if (!record || !record.is_active) return errorResponse(res, 'Admin account not found or deactivated.', 404);
    } else if (target_role === 'auditor') {
      record = await AuditorModel.findByEmail(email);
      if (!record || !record.is_active || !record.email_verified) return errorResponse(res, 'Auditor account not found or not verified.', 404);
    } else {
      record = await OrganizationUserModel.findByEmail(email);
      if (!record || !record.is_active || !record.email_verified) return errorResponse(res, 'Organization user account not found or not verified.', 404);
    }

    if (!record.password) return errorResponse(res, 'Target account has no password set.', 400);

    const isMatch = await bcrypt.compare(password, record.password);
    if (!isMatch) return errorResponse(res, 'Invalid password.', 401);

    // Generate new tokens for the target role
    const tokens = generateTokensForRole(target_role, record);

    const refreshExpiry = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
    const recordId = target_role === 'admin' || target_role === 'audito_admin'
      ? record.admin_id
      : target_role === 'auditor'
        ? record.auditor_id
        : record.organization_user_id;
        const refreshTokenId = await generateRefreshTokenId();

    await db.query(
      'INSERT INTO refresh_tokens (refresh_token_id, admin_id, user_role, token, expires_at) VALUES (?, ?, ?, ?, ?)',
      [refreshTokenId, recordId, target_role, tokens.refreshToken, refreshExpiry]
    );

    if (target_role === 'admin') {
      await AdminModel.updateLastLogin(recordId);
    }

    // Identify & handle plan expiry first so plan limits reflect any downgrade.
    const subscription = await resolveSubscriptionStatus(target_role, record);

    // Fetch plan limits
    const plan_limits = await getPlanLimitsForUser(target_role, record);

    return successResponse(res, {
      admin: { ...buildUserResponse(target_role, record), plan_limits },
      subscription,
      tokens,
    }, 'Account switched successfully.');
  } catch (error) {
    console.error('Switch account error:', error);
    return errorResponse(res, 'Failed to switch account.', 500);
  }
};

// ─── FORGOT PASSWORD (Send OTP) ──────────────────────────────────

/**
 * POST /api/auth/forgot-password
 * Body: { email }
 * Sends a 6-digit OTP to the email address for any verified login account.
 */
const forgotPassword = async (req, res) => {
  try {
    const email = String(req.body?.email || '').trim().toLowerCase();
    if (!email) return errorResponse(res, 'Email is required.', 400);
    if (!isValidEmail(email)) return errorResponse(res, 'Invalid email address.', 400);
    const cooldownSeconds = getResendCooldownSeconds(`password-reset:${email}`);
    if (cooldownSeconds > 0) {
      return errorResponse(res, `Please wait ${cooldownSeconds} second${cooldownSeconds === 1 ? '' : 's'} before requesting another code.`, 429);
    }

    // A single email can be used by an administrator, auditor, and/or entity
    // organizationUser. Every active, verified account that can sign in must be able to
    // request a password reset, not only organization administrators.
    const [admin, auditor, organizationUser] = await Promise.all([
      AdminModel.findByEmail(email),
      AuditorModel.findByEmail(email),
      OrganizationUserModel.findByEmail(email),
    ]);
    const recipient = [
      admin && admin.is_active && admin.is_verified ? admin : null,
      auditor && auditor.is_active && auditor.email_verified && auditor.password ? auditor : null,
      organizationUser && organizationUser.is_active && organizationUser.email_verified && organizationUser.password ? organizationUser : null,
    ].find(Boolean);

    if (!recipient) {
      // Don't reveal whether account exists
      return successResponse(res, null, 'If an account exists with that email, an OTP has been sent.');
    }

    // Generate 6-digit OTP
    const otp = crypto.randomInt(100000, 999999).toString();
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

    // Invalidate previous unused OTPs for this email
    await db.query('UPDATE password_reset_otps SET used = TRUE WHERE email = ? AND used = FALSE', [email]);

    // Store OTP
   const passwordResetOtpId = await generatePasswordResetOtpId();
await db.query(
  'INSERT INTO password_reset_otps (password_reset_otp_id, email, otp, expires_at) VALUES (?, ?, ?, ?)',
  [passwordResetOtpId, email, otp, expiresAt]
);

    // Send OTP email
    try {
      const recipientName = [recipient.first_name, recipient.last_name].filter(Boolean).join(' ') || 'there';
      await sendOtpEmail(email, recipientName, otp);
    } catch (emailErr) {
      console.error('Failed to send OTP email:', emailErr.message);
      return errorResponse(res, 'Failed to send OTP email. Please try again.', 500);
    }

    recordResend(`password-reset:${email}`);
    return successResponse(res, null, 'If an account exists with that email, an OTP has been sent.');
  } catch (error) {
    console.error('Forgot password error:', error);
    return errorResponse(res, 'Failed to process request.', 500);
  }
};

// ─── VERIFY OTP ──────────────────────────────────────────────────

/**
 * POST /api/auth/verify-otp
 * Body: { email, otp }
 * Verifies the OTP and returns a temporary reset token.
 */
/** Resends a pending organization, invitation, or custom-plan verification email. */
const resendVerificationEmail = async (req, res) => {
  try {
    const email = String(req.body?.email || '').trim();
    if (!email) return errorResponse(res, 'Email is required.', 400);
    if (!isValidEmail(email)) return errorResponse(res, 'Invalid email address.', 400);

    const cooldownKey = `verification:${email}`;
    const cooldownSeconds = getResendCooldownSeconds(cooldownKey);
    if (cooldownSeconds > 0) {
      return errorResponse(res, `Please wait ${cooldownSeconds} second${cooldownSeconds === 1 ? '' : 's'} before resending the verification email.`, 429);
    }

    const admin = await AdminModel.findByEmail(email);
    if (admin && !admin.is_verified) {
      const token = crypto.randomBytes(32).toString('hex');
      await AdminModel.setVerificationToken(admin.admin_id, token);
      const organizationName = await getOrgName(admin.entity_type, admin.entity_code);
      await sendOrganizationRegistrationVerificationEmail(admin.email, admin.first_name, token, organizationName || admin.entity_code);
      recordResend(cooldownKey);
      return successResponse(res, null, 'A verification email has been sent if the account is awaiting verification.');
    }

    const resendInvitation = async (record, type) => {
      const token = crypto.randomBytes(32).toString('hex');
      const expiresAt = new Date(Date.now() + 48 * 60 * 60 * 1000);
      const model = type === 'auditor' ? AuditorModel : OrganizationUserModel;
      const recordId = type === 'auditor' ? record.auditor_id : record.organization_user_id;
      await model.regenerateToken(recordId, token, expiresAt);

      const ownerAdmin = record.created_by_entity_code
        ? await AdminModel.findByEntityCode(record.created_by_entity_code)
        : null;
      const organization = ownerAdmin
        ? await getOrgDetails(ownerAdmin.entity_type, record.created_by_entity_code)
        : null;
      const dialingCode = await getCountryDialingCode(organization?.country);
      await sendUserInvitationEmail(record.email, `${record.first_name} ${record.last_name}`, token, {
        organizationName: organization?.name || record.created_by_entity_code || 'your organization',
        organizationEmail: organization?.email,
        organizationPhone: organization?.phoneNumber,
        organizationDialingCode: dialingCode,
        organizationAddress: organization?.address,
        role: record.user_type || (type === 'auditor' ? 'Auditor' : 'Organization User'),
        includeAssignedArea: type === 'organization_user',
        assignedEntityType: type === 'organization_user' ? record.assigned_entity_type : null,
        assignedEntityName: type === 'organization_user' ? record.assigned_entity_code : null,
      });
    };

    const auditor = await AuditorModel.findByEmail(email);
    if (auditor && !auditor.email_verified && auditor.is_active) {
      await resendInvitation(auditor, 'auditor');
      recordResend(cooldownKey);
      return successResponse(res, null, 'A verification email has been sent if the account is awaiting verification.');
    }

    const organizationUser = await OrganizationUserModel.findByEmail(email);
    if (organizationUser && !organizationUser.email_verified && organizationUser.is_active) {
      await resendInvitation(organizationUser, 'organization_user');
      recordResend(cooldownKey);
      return successResponse(res, null, 'A verification email has been sent if the account is awaiting verification.');
    }

    const [customRows] = await db.query(
      `SELECT request_id, org_name, org_email
       FROM custom_solution_requests
       WHERE org_email = ? AND email_verified = FALSE AND verification_expires_at IS NOT NULL
       ORDER BY created_at DESC LIMIT 1`,
      [email]
    );
    if (customRows[0]) {
      const token = crypto.randomBytes(32).toString('hex');
      await db.query(
        `UPDATE custom_solution_requests
         SET verification_token = ?, verification_expires_at = ?
         WHERE request_id = ?`,
        [token, new Date(Date.now() + 48 * 60 * 60 * 1000), customRows[0].request_id]
      );
      await sendCustomSolutionVerificationEmail(customRows[0].org_email, customRows[0].org_name, token);
      recordResend(cooldownKey);
    }

    return successResponse(res, null, 'A verification email has been sent if the account is awaiting verification.');
  } catch (error) {
    console.error('Resend verification email error:', error);
    return errorResponse(res, 'Unable to resend the verification email. Please try again.', 500);
  }
};

const verifyOtp = async (req, res) => {
  try {
    const { otp } = req.body;
    const email = String(req.body?.email || '').trim().toLowerCase();
    const missing = validateRequiredFields({ email, otp }, ['email', 'otp']);
    if (missing) return errorResponse(res, missing, 400);

    const [rows] = await db.query(
      'SELECT * FROM password_reset_otps WHERE email = ? AND otp = ? AND used = FALSE AND expires_at > NOW() ORDER BY created_at DESC LIMIT 1',
      [email, otp]
    );

    if (rows.length === 0) {
      return errorResponse(res, 'Invalid or expired OTP.', 400);
    }

    // Mark OTP as used
    await db.query('UPDATE password_reset_otps SET used = TRUE WHERE password_reset_otp_id = ?', [rows[0].password_reset_otp_id]);

    // Generate a temporary reset token (valid for 5 minutes)
    const resetToken = crypto.randomBytes(32).toString('hex');
    const resetExpiry = new Date(Date.now() + 5 * 60 * 1000);

    // Store reset token in a new OTP row (reuse table with special otp value)
   const resetRowId = await generatePasswordResetOtpId();
await db.query(
  'INSERT INTO password_reset_otps (password_reset_otp_id, email, otp, expires_at, used) VALUES (?, ?, ?, ?, FALSE)',
  [resetRowId, email, `RST-${resetToken}`, resetExpiry]
);

    return successResponse(res, { reset_token: resetToken }, 'OTP verified. You can now reset your password.');
  } catch (error) {
    console.error('Verify OTP error:', error);
    return errorResponse(res, 'Verification failed.', 500);
  }
};

// ─── RESET PASSWORD ──────────────────────────────────────────────

/**
 * POST /api/auth/reset-password
 * Body: { email, reset_token, new_password }
 * Resets the password after OTP verification.
 */
const resetPassword = async (req, res) => {
  try {
    const { reset_token, new_password } = req.body;
    const email = String(req.body?.email || '').trim().toLowerCase();
    const missing = validateRequiredFields({ email, reset_token, new_password }, ['email', 'reset_token', 'new_password']);
    if (missing) return errorResponse(res, missing, 400);

    if (new_password.length < 8) return errorResponse(res, 'Password must be at least 8 characters.', 400);

    // Verify reset token
    const [rows] = await db.query(
      'SELECT * FROM password_reset_otps WHERE email = ? AND otp = ? AND used = FALSE AND expires_at > NOW() ORDER BY created_at DESC LIMIT 1',
      [email, `RST-${reset_token}`]
    );

    if (rows.length === 0) {
      return errorResponse(res, 'Invalid or expired reset token. Please start over.', 400);
    }

    // Mark token as used
    await db.query('UPDATE password_reset_otps SET used = TRUE WHERE password_reset_otp_id = ?', [rows[0].password_reset_otp_id]);

    // Find admin — required (forgot password is admin-initiated)
    const [admin, auditor, organizationUser] = await Promise.all([
      AdminModel.findByEmail(email),
      AuditorModel.findByEmail(email),
      OrganizationUserModel.findByEmail(email),
    ]);
    const accounts = [
      { type: 'admin', record: admin },
      { type: 'auditor', record: auditor },
      { type: 'organization_user', record: organizationUser },
    ].filter(({ record }) => record?.is_active);

    if (accounts.length === 0) return errorResponse(res, 'Account not found.', 404);

    const salt = await bcrypt.genSalt(12);
    const hashedPassword = await bcrypt.hash(new_password, salt);

    // Keep every active role sharing this email in sync after a reset.
    await Promise.all(accounts.map(({ type, record }) => {
      if (type === 'admin') return AdminModel.updatePassword(record.admin_id, hashedPassword);
      if (type === 'auditor') return AuditorModel.setPassword(record.auditor_id, hashedPassword);
      return OrganizationUserModel.setPassword(record.organization_user_id, hashedPassword);
    }));

    return successResponse(res, null, 'Password reset successfully. You can now log in.');
  } catch (error) {
    console.error('Reset password error:', error);
    return errorResponse(res, 'Failed to reset password.', 500);
  }
};

// ─── VERIFY EMAIL ────────────────────────────────────────────────

/**
 * POST /api/auth/verify-email
 * Body: { token }
 */
const verifyEmail = async (req, res) => {
  try {
    const { token } = req.body;
    if (!token) return errorResponse(res, 'Verification token is required.', 400);

    // 1. Check Admins (uses verification_token)
    const admin = await AdminModel.findByVerificationToken(token);
    if (admin) {
      const needsPassword = !admin.password;
      if (needsPassword) {
        // Invited admin — return info so frontend can show set-password form
        return successResponse(res, {
          email: admin.email,
          first_name: admin.first_name,
          needs_password: true,
          admin_id: admin.admin_id,
        }, 'Email verified. Please set your password.', 200);
      }
      await AdminModel.markAsVerified(admin.admin_id);
      const pendingPayment = await PaymentModel.findPendingByOrgPurpose(admin.entity_code, 'registration');

      // Check if this is a custom solution that has been priced
      let customSolutionPayment = null;
      let custom_solution_pending = false;
      if (!pendingPayment && admin.entity_code) {
        const customReq = await CustomSolutionModel.findByOrgCode(admin.entity_code);
        if (customReq) {
          if (customReq.status === 'priced' && customReq.payment_code) {
            const cp = await PaymentModel.findByCode(customReq.payment_code);
            if (cp && cp.status === 'pending') {
              customSolutionPayment = {
                payment_code: cp.payment_code,
                plan_name: 'Custom',
                billing_cycle: cp.billing_cycle,
                amount: Number(cp.amount),
              };
            }
          } else if (customReq.status === 'pending') {
            custom_solution_pending = true;
          }
        }
      }

      return successResponse(res, {
        email: admin.email,
        first_name: admin.first_name,
        needs_password: false,
        custom_solution_pending,
        payment: pendingPayment
          ? {
              payment_code: pendingPayment.payment_code,
              plan_name: pendingPayment.plan_name,
              billing_cycle: pendingPayment.billing_cycle,
              amount: Number(pendingPayment.amount),
            }
          : customSolutionPayment,
      }, 'Email verified successfully. You may now log in.', 200);
    }

    // Custom solution requests are verified before a workspace admin exists.
    const customRequest = await CustomSolutionModel.findByVerificationToken(token);
    if (customRequest) {
      await CustomSolutionModel.verifyEmail(customRequest.request_id);
      const [auditoAdmins] = await db.query(
        `SELECT email FROM admins
         WHERE role = 'audito_admin' AND is_active = TRUE AND is_verified = TRUE`
      );
      const recipients = auditoAdmins.map((item) => item.email).filter(Boolean);
      if (recipients.length) {
        sendCustomSolutionRequestEmail(recipients, {
          orgName: customRequest.org_name,
          orgEmail: customRequest.org_email,
          entityType: customRequest.entity_type,
        }).catch((err) => console.error('Failed to notify Audito admins of custom request:', err));
      }
      return successResponse(res, {
        email: customRequest.org_email,
        custom_solution_pending: true,
        needs_password: false,
      }, 'Organization email verified. Your custom solution request is now with our pricing team.', 200);
    }

    // 2. Check Auditors (uses email_token + expires)
    const auditor = await AuditorModel.findByEmailToken(token);
    if (auditor) {
      await AuditorModel.verifyEmail(auditor.auditor_id);
      return successResponse(res, {
        email: auditor.email,
        first_name: auditor.first_name,
        needs_password: !auditor.password
      }, 'Email verified successfully.', 200);
    }

    // 3. Check Organization Users (uses email_token + expires)
    const organizationUser = await OrganizationUserModel.findByEmailToken(token);
    if (organizationUser) {
      await OrganizationUserModel.verifyEmail(organizationUser.organization_user_id);
      return successResponse(res, {
        email: organizationUser.email,
        first_name: organizationUser.first_name,
        needs_password: !organizationUser.password
      }, 'Email verified successfully.', 200);
    }

    return errorResponse(res, 'Invalid or expired verification token.', 400);
  } catch (error) {
    console.error('Verify email error:', error);
    return errorResponse(res, 'Verification failed.', 500);
  }
};

// ─── UPDATE PROFILE ─────────────────────────────────────────────

/**
 * PUT /api/auth/profile
 * Updates the logged-in user's name, phone, NIC and country.
 */
const saveProfileImage = (role, userId, base64Str) => {
  if (!base64Str) return null;

  if (base64Str.startsWith('/uploads/profile-images/')) {
    return base64Str;
  }

  const matches = base64Str.match(/^data:image\/([A-Za-z0-9-+]+);base64,(.+)$/);
  if (!matches || matches.length !== 3) {
    throw new Error('Invalid image base64 format');
  }

  const ext = matches[1] === 'jpeg' ? 'jpg' : matches[1];
  const dataBuffer = Buffer.from(matches[2], 'base64');

  const targetDir = path.join(__dirname, '..', 'public', 'uploads', 'profile-images');

  if (!fs.existsSync(targetDir)) {
    fs.mkdirSync(targetDir, { recursive: true });
  }

  const filename = `avatar_${role}_${userId}_${Date.now()}.${ext}`;
  const filePath = path.join(targetDir, filename);

  fs.writeFileSync(filePath, dataBuffer);

  return `/uploads/profile-images/${filename}`;
};

const updateProfile = async (req, res) => {
  try {
    const role = req.user.role;
    const { first_name, last_name, phone_number, country, profile_image } = req.body;

    if (!first_name || !last_name) {
      return errorResponse(res, 'first_name and last_name are required.', 400);
    }

    // 1. Fetch old profile_image path
    let oldProfileImage = null;
    if (role === 'admin' || role === 'audito_admin') {
      const [rows] = await db.query('SELECT profile_image FROM admins WHERE admin_id = ?', [req.user.userCode]);
      if (rows && rows.length > 0) oldProfileImage = rows[0].profile_image;
    } else if (role === 'auditor') {
      const [rows] = await db.query('SELECT profile_image FROM auditors WHERE auditor_id = ?', [req.user.userCode]);
      if (rows && rows.length > 0) oldProfileImage = rows[0].profile_image;
    } else if (role === 'organization_user') {
      const [rows] = await db.query('SELECT profile_image FROM organization_users WHERE organization_user_id = ?', [req.user.userCode]);
      if (rows && rows.length > 0) oldProfileImage = rows[0].profile_image;
    }

    // 2. Process image path and write file to disk if base64
    let finalProfileImagePath = null;
    if (profile_image) {
      if (profile_image.startsWith('data:image/')) {
        finalProfileImagePath = saveProfileImage(role, req.user.userCode, profile_image);

        // Delete old image file
        if (oldProfileImage && oldProfileImage.startsWith('/uploads/profile-images/')) {
          const oldFilePath = path.join(__dirname, '..', 'public', oldProfileImage);
          if (fs.existsSync(oldFilePath)) {
            try {
              fs.unlinkSync(oldFilePath);
            } catch (err) {
              console.error('Failed to delete old avatar:', err);
            }
          }
        }
      } else {
        finalProfileImagePath = profile_image;
      }
    } else {
      // User removed their avatar
      finalProfileImagePath = null;
      if (oldProfileImage && oldProfileImage.startsWith('/uploads/profile-images/')) {
        const oldFilePath = path.join(__dirname, '..', 'public', oldProfileImage);
        if (fs.existsSync(oldFilePath)) {
          try {
            fs.unlinkSync(oldFilePath);
          } catch (err) {
            console.error('Failed to delete old avatar:', err);
          }
        }
      }
    }

    // 3. Update in Database
    if (role === 'admin' || role === 'audito_admin') {
      await db.query(
        'UPDATE admins SET first_name = ?, last_name = ?, phone_number = ?, country = ?, profile_image = ? WHERE admin_id = ?',
        [first_name.trim(), last_name.trim(), phone_number || null, country || null, finalProfileImagePath, req.user.userCode]
      );
    } else if (role === 'auditor') {
      await db.query(
        'UPDATE auditors SET first_name = ?, last_name = ?, phone_number = ?, country = ?, profile_image = ? WHERE auditor_id = ?',
        [first_name.trim(), last_name.trim(), phone_number || null, country || null, finalProfileImagePath, req.user.userCode]
      );
    } else if (role === 'organization_user') {
      await db.query(
        'UPDATE organization_users SET first_name = ?, last_name = ?, phone_number = ?, country = ?, profile_image = ? WHERE organization_user_id = ?',
        [first_name.trim(), last_name.trim(), phone_number || null, country || null, finalProfileImagePath, req.user.userCode]
      );
    } else {
      return errorResponse(res, 'Invalid role.', 400);
    }

    return successResponse(res, null, 'Profile updated successfully.');
  } catch (error) {
    console.error('updateProfile error:', error);
    return errorResponse(res, 'Failed to update profile.', 500);
  }
};

/**
 * GET /api/auth/onboarding
 * Returns onboarding status for current admin.
 */
const getOnboardingStatus = async (req, res) => {
  try {
    const role = req.user.role;
    let record = null;
    let status = null;

    if (role === 'admin') {
      record = await AdminModel.findById(req.user.userCode);
      status = await AdminModel.getOnboardingStatus(req.user.userCode);
    } else if (role === 'auditor') {
      record = await AuditorModel.findById(req.user.userCode);
      status = await AuditorModel.getOnboardingStatus(req.user.userCode);
    } else if (role === 'organization_user') {
      record = await OrganizationUserModel.findById(req.user.userCode);
      status = await OrganizationUserModel.getOnboardingStatus(req.user.userCode);
    } else {
      return errorResponse(res, 'Only valid system users can access onboarding status.', 403);
    }

    if (!record) return errorResponse(res, `${role.replace('_', ' ')} not found.`, 404);
    if (!status) return errorResponse(res, 'Onboarding status not available.', 404);

    return successResponse(res, {
      onboarding_completed: !!status.onboarding_completed,
      onboarding_skipped: !!status.onboarding_skipped,
      onboarding_completed_at: status.onboarding_completed_at || null,
    });
  } catch (error) {
    console.error('getOnboardingStatus error:', error);
    return errorResponse(res, 'Failed to fetch onboarding status.', 500);
  }
};

/**
 * PUT /api/auth/onboarding
 * Body: { action: 'complete' | 'skip' | 'reset' }
 */
const updateOnboardingStatus = async (req, res) => {
  try {
    const role = req.user.role;
    const { action } = req.body;
    if (!['complete', 'skip', 'reset'].includes(action)) {
      return errorResponse(res, "Invalid action. Use 'complete', 'skip', or 'reset'.", 400);
    }

    let record = null;
    if (role === 'admin') {
      record = await AdminModel.findById(req.user.userCode);
    } else if (role === 'auditor') {
      record = await AuditorModel.findById(req.user.userCode);
    } else if (role === 'organization_user') {
      record = await OrganizationUserModel.findById(req.user.userCode);
    } else {
      return errorResponse(res, 'Only valid system users can update onboarding status.', 403);
    }

    if (!record) return errorResponse(res, `${role.replace('_', ' ')} not found.`, 404);

    if (role === 'admin') {
      if (action === 'complete') {
        await AdminModel.updateOnboardingStatus(record.admin_id, { completed: true, skipped: false });
      } else if (action === 'skip') {
        await AdminModel.updateOnboardingStatus(record.admin_id, { completed: false, skipped: true });
      } else {
        await AdminModel.resetOnboardingStatus(record.admin_id);
      }
    } else if (role === 'auditor') {
      if (action === 'complete') {
        await AuditorModel.updateOnboardingStatus(record.auditor_id, { completed: true, skipped: false });
      } else if (action === 'skip') {
        await AuditorModel.updateOnboardingStatus(record.auditor_id, { completed: false, skipped: true });
      } else {
        await AuditorModel.resetOnboardingStatus(record.auditor_id);
      }
    } else if (role === 'organization_user') {
      if (action === 'complete') {
        await OrganizationUserModel.updateOnboardingStatus(record.organization_user_id, { completed: true, skipped: false });
      } else if (action === 'skip') {
        await OrganizationUserModel.updateOnboardingStatus(record.organization_user_id, { completed: false, skipped: true });
      } else {
        await OrganizationUserModel.resetOnboardingStatus(record.organization_user_id);
      }
    }

    const updatedStatus =
      role === 'admin'
        ? await AdminModel.getOnboardingStatus(record.admin_id)
        : role === 'auditor'
          ? await AuditorModel.getOnboardingStatus(record.auditor_id)
          : await OrganizationUserModel.getOnboardingStatus(record.organization_user_id);

    return successResponse(res, {
      onboarding_completed: !!updatedStatus.onboarding_completed,
      onboarding_skipped: !!updatedStatus.onboarding_skipped,
      onboarding_completed_at: updatedStatus.onboarding_completed_at || null,
    }, 'Onboarding status updated.');
  } catch (error) {
    console.error('updateOnboardingStatus error:', error);
    return errorResponse(res, 'Failed to update onboarding status.', 500);
  }
};

const validatePromoCode = async (req, res) => {
  try {
    const { code } = req.body;
    if (!code) {
      return errorResponse(res, 'Promo code is required.', 400);
    }

    const promo = await PromoCodeModel.findByCode(code);
    if (!promo) {
      return errorResponse(res, 'Invalid or expired promo code.', 404);
    }

    return successResponse(res, {
      code: promo.code,
      discount_percentage: parseFloat(promo.discount_percentage)
    }, 'Promo code is valid.');
  } catch (error) {
    console.error('Validate promo code error:', error);
    return errorResponse(res, 'Failed to validate promo code.', 500);
  }
};

// ─── SET ADMIN PASSWORD (PUBLIC) ────────────────────────────────

/**
 * POST /api/auth/set-admin-password
 * Body: { token, password }
 *
 * Invited admin sets their password after email verification.
 */
const setAdminPassword = async (req, res) => {
  try {
    const { token, password } = req.body;

    if (!token || !password) {
      return errorResponse(res, 'Token and password are required.', 400);
    }

    if (password.length < 8) {
      return errorResponse(res, 'Password must be at least 8 characters.', 400);
    }

    const admin = await AdminModel.findByVerificationToken(token);
    if (!admin) {
      return errorResponse(res, 'Invalid or expired verification link.', 400);
    }

    // If already has a password and is verified, this is a re-use
    if (admin.password && admin.is_verified) {
      return errorResponse(res, 'Password already set. Please log in.', 400);
    }

    const hashed = await bcrypt.hash(password, 12);
    await AdminModel.setAdminPassword(admin.admin_id, hashed);

    return successResponse(res, {
      email: admin.email,
      first_name: admin.first_name,
    }, 'Password set successfully. You can now log in.');
  } catch (error) {
    console.error('Set admin password error:', error);
    return errorResponse(res, 'Failed to set password.', 500);
  }
};

/**
 * GET /api/auth/custom-solution/setup-admin/:paymentCode
 * Returns the verified organization email for the administrator setup screen.
 */
const getCustomSolutionAdminSetup = async (req, res) => {
  try {
    const payment = await PaymentModel.findByCode(req.params.paymentCode);
    if (!payment || payment.plan_name !== 'Custom' || payment.purpose !== 'registration') {
      return errorResponse(res, 'Invalid custom-plan payment.', 404);
    }

    const request = await CustomSolutionModel.findByPaymentCode(payment.payment_code);
    if (!request?.email_verified) {
      return errorResponse(res, 'The custom solution request is not verified.', 403);
    }

    const config = ENTITY_CONFIG[request.entity_type];
    if (!config) return errorResponse(res, 'Invalid organization type for this custom request.', 400);
    const [orgRows] = await db.query(
      `SELECT country FROM \`${config.table}\` WHERE \`${config.codeField}\` = ? LIMIT 1`,
      [request.root_entity_code]
    );

    return successResponse(res, {
      email: request.org_email,
      country: orgRows[0]?.country || null,
    }, 'Custom solution setup details retrieved.');
  } catch (error) {
    console.error('getCustomSolutionAdminSetup error:', error);
    return errorResponse(res, 'Failed to retrieve administrator setup details.', 500);
  }
};

/**
 * POST /api/auth/check-registration-email
 * Checks the organization email that will also be used for the initial admin.
 */
const checkRegistrationEmail = async (req, res) => {
  try {
    const email = String(req.body?.email || '').trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return errorResponse(res, 'Enter a valid organization email address.', 400);
    }
    if (await AdminModel.emailExists(email)) {
      return errorResponse(res, 'This organization email is already registered. Please use a different email.', 409);
    }
    return successResponse(res, { available: true }, 'Email is available.');
  } catch (error) {
    console.error('checkRegistrationEmail error:', error);
    return errorResponse(res, 'Unable to check email availability.', 500);
  }
};

/**
 * POST /api/auth/custom-solution/setup-admin
 * Creates the first workspace admin after organization verification and before payment.
 */
const setupCustomSolutionAdmin = async (req, res) => {
  try {
    const { payment_code, first_name, last_name, phone_number, password } = req.body;
    const missing = validateRequiredFields(req.body, ['payment_code', 'first_name', 'last_name', 'phone_number', 'password']);
    if (missing) return errorResponse(res, missing, 400);

    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&#])[A-Za-z\d@$!%*?&#]{8,}$/;
    if (!passwordRegex.test(password)) {
      return errorResponse(res, 'Password must be at least 8 characters and include uppercase, lowercase, number, and special character.', 400);
    }

    const payment = await PaymentModel.findByCode(payment_code);
    if (!payment || payment.plan_name !== 'Custom' || payment.purpose !== 'registration') {
      return errorResponse(res, 'Invalid custom-plan payment.', 404);
    }
    if (!['pending', 'failed'].includes(payment.status)) {
      return errorResponse(res, 'This payment can no longer be used to set up the administrator account.', 409);
    }

    const request = await CustomSolutionModel.findByPaymentCode(payment_code);
    if (!request || !request.email_verified) {
      return errorResponse(res, 'The custom solution request is not verified.', 403);
    }
    if (request.admin_setup_completed || request.admin_id) {
      return successResponse(res, { email: request.org_email, payment_code }, 'Administrator account is already set up. Continue to payment to activate the workspace.');
    }
    if (await AdminModel.emailExists(request.org_email)) {
      return errorResponse(res, 'An account already exists for this organization email. Please contact support.', 409);
    }

    const config = ENTITY_CONFIG[request.entity_type];
    if (!config) return errorResponse(res, 'Invalid organization type for this custom request.', 400);
    const [orgRows] = await db.query(
      `SELECT country FROM \`${config.table}\` WHERE \`${config.codeField}\` = ? LIMIT 1`,
      [request.root_entity_code]
    );
    if (!orgRows.length) return errorResponse(res, 'Organization not found.', 404);

    const adminId = await generateAdminUserCode();
    const hashedPassword = await bcrypt.hash(password, 12);
    await AdminModel.create({
      admin_id: adminId,
      first_name: first_name.trim(),
      last_name: last_name.trim(),
      email: request.org_email,
      country: orgRows[0].country || null,
      phone_number: phone_number?.trim() || null,
      password: hashedPassword,
      account_type: config.account_type,
      entity_type: request.entity_type,
      entity_code: request.root_entity_code,
      org_level: config.org_level,
    });
    await AdminModel.markAsVerified(adminId);
    // Credentials are ready for checkout, but access remains blocked until payment activates the plan.
    await AdminModel.deactivate(adminId);
    await CustomSolutionModel.completeAdminSetup(request.request_id, adminId);

    return successResponse(res, { email: request.org_email, payment_code }, 'Administrator account created. Continue to payment to activate the workspace.', 201);
  } catch (error) {
    console.error('setupCustomSolutionAdmin error:', error);
    return errorResponse(res, 'Failed to create administrator account.', 500);
  }
};

module.exports = {
  register,
  login,
  refreshToken,
  logout,
  getMe,
  changePassword,
  switchAccount,
  forgotPassword,
  resendVerificationEmail,
  verifyOtp,
  resetPassword,
  verifyEmail,
  setAdminPassword,
  checkRegistrationEmail,
  getCustomSolutionAdminSetup,
  setupCustomSolutionAdmin,
  updateProfile,
  updateOrganization,
  getOnboardingStatus,
  updateOnboardingStatus,
  validatePromoCode,
};
